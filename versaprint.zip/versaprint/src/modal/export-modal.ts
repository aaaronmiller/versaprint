import { App, Modal, Setting, Notice } from 'obsidian';
import VersaPrintPlugin from '../main';
import { ExportProfile } from '../types/interfaces';

export class ExportModal extends Modal {
  plugin: VersaPrintPlugin;
  profile: ExportProfile;
  originalProfile: ExportProfile; // To revert if 


import { App, Modal, Setting, Notice } from 'obsidian';
import VersaPrintPlugin from '../main';
import { ExportProfile } from '../types/interfaces';
import { ThemeManager } from '../core/theme-manager';

export class ExportModal extends Modal {
  plugin: VersaPrintPlugin;
  profile: ExportProfile;
  originalProfile: ExportProfile; // To revert if 'Custom Settings' is selected
  themeManager: ThemeManager;

  constructor(app: App, plugin: VersaPrintPlugin) {
    super(app);
    this.plugin = plugin;
    this.themeManager = new ThemeManager(app);
    // Deep copy the default profile to allow temporary modifications
    this.profile = JSON.parse(JSON.stringify(this.plugin.getDefaultProfile() || this.createEmptyProfile()));
    this.originalProfile = JSON.parse(JSON.stringify(this.profile));
  }

  private createEmptyProfile(): ExportProfile {
    return {
      id: 'custom',
      name: 'Custom Settings',
      outputFormat: 'pdf',
      targetTheme: 'obsidian-default',
      useArxivStyle: false,
      padding: {
        top: 20,
        right: 20,
        bottom: 20,
        left: 20,
        unit: 'mm',
      },
      enabledSnippets: [],
      created: Date.now(),
      lastModified: Date.now(),
    };
  }

  async onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl('h2', { text: 'VersaPrint Export' });

    await this.themeManager.getAvailableThemes(); // Ensure themes are loaded

    // Export Profile Dropdown
    new Setting(contentEl)
      .setName('Export Profile')
      .setDesc('Select a saved export profile or use custom settings.')
      .addDropdown(dropdown => {
        dropdown.addOption('custom', 'Custom Settings');
        this.plugin.settings.profiles.forEach(profile => {
          dropdown.addOption(profile.id, profile.name);
        });
        dropdown.setValue(this.profile.id);
        dropdown.onChange(async (value) => {
          if (value === 'custom') {
            this.profile = JSON.parse(JSON.stringify(this.originalProfile));
          } else {
            const selectedProfile = this.plugin.settings.profiles.find(p => p.id === value);
            if (selectedProfile) {
              this.profile = JSON.parse(JSON.stringify(selectedProfile));
            }
          }
          this.display(); // Re-render modal with new profile settings
        });
      });

    // Output Format Buttons
    new Setting(contentEl)
      .setName('Output Format')
      .setDesc('Choose the desired output format.')
      .addButton(button => {
        button.setButtonText('PDF')
          .setCta(this.profile.outputFormat === 'pdf')
          .onClick(() => {
            this.profile.outputFormat = 'pdf';
            this.display();
          });
      })
      .addButton(button => {
        button.setButtonText('HTML')
          .setCta(this.profile.outputFormat === 'html')
          .onClick(() => {
            this.profile.outputFormat = 'html';
            this.display();
          });
      });

    // Theme Dropdown
    const themeSetting = new Setting(contentEl)
      .setName('Theme')
      .setDesc('Select the theme to use for export.');

    themeSetting.addDropdown(dropdown => {
      this.themeManager.getAvailableThemes().forEach(theme => {
        dropdown.addOption(theme.id, theme.name);
      });
      dropdown.setValue(this.profile.targetTheme);
      dropdown.onChange(value => {
        this.profile.targetTheme = value;
      });
    });

    // Use arXiv Style Toggle
    new Setting(contentEl)
      .setName('Use arXiv Style')
      .setDesc('Override selected theme with a bundled arXiv academic style.')
      .addToggle(toggle => {
        toggle.setValue(this.profile.useArxivStyle)
          .onChange(value => {
            this.profile.useArxivStyle = value;
            themeSetting.setDisabled(value); // Disable theme dropdown if arXiv style is used
          });
      });
    themeSetting.setDisabled(this.profile.useArxivStyle); // Initial state

    // Page Padding (PDF only)
    if (this.profile.outputFormat === 'pdf') {
      const paddingSetting = new Setting(contentEl)
        .setName('Page Padding')
        .setDesc('Set custom page margins for PDF export.');

      paddingSetting.addText(text => text
        .setPlaceholder('Top')
        .setValue(this.profile.padding.top.toString())
        .onChange(value => this.profile.padding.top = parseFloat(value) || 0)
      );
      paddingSetting.addText(text => text
        .setPlaceholder('Right')
        .setValue(this.profile.padding.right.toString())
        .onChange(value => this.profile.padding.right = parseFloat(value) || 0)
      );
      paddingSetting.addText(text => text
        .setPlaceholder('Bottom')
        .setValue(this.profile.padding.bottom.toString())
        .onChange(value => this.profile.padding.bottom = parseFloat(value) || 0)
      );
      paddingSetting.addText(text => text
        .setPlaceholder('Left')
        .setValue(this.profile.padding.left.toString())
        .onChange(value => this.profile.padding.left = parseFloat(value) || 0)
      );
      paddingSetting.addDropdown(dropdown => dropdown
        .addOption('mm', 'mm')
        .addOption('in', 'in')
        .addOption('px', 'px')
        .setValue(this.profile.padding.unit)
        .onChange(value => this.profile.padding.unit = value as 'mm' | 'in' | 'px')
      );
    }

    // CSS Snippets (Multi-select List - Placeholder for custom DOM)
    new Setting(contentEl)
      .setName('CSS Snippets')
      .setDesc('Select CSS snippets to apply during export (filtered by output format).')
      .addText(text => {
        text.setPlaceholder('Snippet selection UI to be implemented')
          .setDisabled(true); // This will be replaced by custom UI
      });

    // Export Button
    new Setting(contentEl)
      .addButton(button => {
        button.setButtonText('Export')
          .setCta()
          .onClick(async () => {
            this.close();
            if (this.profile.outputFormat === 'pdf') {
              await this.plugin.exportEngine.exportToPDF(this.profile);
            } else {
              await this.plugin.exportEngine.exportToHTML(this.profile);
            }
          });
      });
  }

  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
}


