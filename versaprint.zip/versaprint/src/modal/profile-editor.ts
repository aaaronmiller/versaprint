import { App, Modal, Setting, Notice } from 'obsidian';
import { ExportProfile } from '../types/interfaces';
import VersaPrintPlugin from '../main';

export class ProfileEditorModal extends Modal {
  plugin: VersaPrintPlugin;
  profile: ExportProfile;
  isNew: boolean;
  onSubmit: (profile: ExportProfile) => void;

  constructor(app: App, plugin: VersaPrintPlugin, profile?: ExportProfile, onSubmit?: (profile: ExportProfile) => void) {
    super(app);
    this.plugin = plugin;
    this.isNew = !profile;
    this.profile = profile ? JSON.parse(JSON.stringify(profile)) : this.createEmptyProfile();
    this.onSubmit = onSubmit || (() => {});
  }

  private createEmptyProfile(): ExportProfile {
    return {
      id: `vp-profile-${Date.now()}`,
      name: `New Profile ${this.plugin.settings.profiles.length + 1}`,
      outputFormat: 'pdf',
      targetTheme: 'obsidian-default',
      useArxivStyle: false,
      padding: {
        top: 20,
        right: 20,
        bottom: 20,
        left: 20,
        unit: 'mm',
      },
      enabledSnippets: [],
      created: Date.now(),
      lastModified: Date.now(),
    };
  }

  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl('h2', { text: this.isNew ? 'Create New Export Profile' : 'Edit Export Profile' });

    new Setting(contentEl)
      .setName('Profile Name')
      .setDesc('A unique name for this export profile.')
      .addText(text => text
        .setValue(this.profile.name)
        .onChange(value => this.profile.name = value)
      );

    new Setting(contentEl)
      .setName('Output Format')
      .setDesc('Choose the default output format for this profile.')
      .addDropdown(dropdown => dropdown
        .addOption('pdf', 'PDF')
        .addOption('html', 'HTML')
        .setValue(this.profile.outputFormat)
        .onChange(value => this.profile.outputFormat = value as 'pdf' | 'html')
      );

    new Setting(contentEl)
      .setName('Target Theme')
      .setDesc('The Obsidian theme to use for export.')
      .addDropdown(async dropdown => {
        const themes = await this.plugin.exportEngine.themeManager.getAvailableThemes();
        themes.forEach(theme => {
          dropdown.addOption(theme.id, theme.name);
        });
        dropdown.setValue(this.profile.targetTheme);
        dropdown.onChange(value => this.profile.targetTheme = value);
      });

    new Setting(contentEl)
      .setName('Use arXiv Style')
      .setDesc('Override selected theme with a bundled arXiv academic style.')
      .addToggle(toggle => toggle
        .setValue(this.profile.useArxivStyle)
        .onChange(value => this.profile.useArxivStyle = value)
      );

    const paddingSetting = new Setting(contentEl)
      .setName('Page Padding')
      .setDesc('Set custom page margins for PDF export (Top, Right, Bottom, Left).');

    paddingSetting.addText(text => text
      .setPlaceholder('Top')
      .setValue(this.profile.padding.top.toString())
      .onChange(value => this.profile.padding.top = parseFloat(value) || 0)
    );
    paddingSetting.addText(text => text
      .setPlaceholder('Right')
      .setValue(this.profile.padding.right.toString())
      .onChange(value => this.profile.padding.right = parseFloat(value) || 0)
    );
    paddingSetting.addText(text => text
      .setPlaceholder('Bottom')
      .setValue(this.profile.padding.bottom.toString())
      .onChange(value => this.profile.padding.bottom = parseFloat(value) || 0)
    );
    paddingSetting.addText(text => text
      .setPlaceholder('Left')
      .setValue(this.profile.padding.left.toString())
      .onChange(value => this.profile.padding.left = parseFloat(value) || 0)
    );
    paddingSetting.addDropdown(dropdown => dropdown
      .addOption('mm', 'mm')
      .addOption('in', 'in')
      .addOption('px', 'px')
      .setValue(this.profile.padding.unit)
      .onChange(value => this.profile.padding.unit = value as 'mm' | 'in' | 'px')
    );

    new Setting(contentEl)
      .setName('Enabled CSS Snippets')
      .setDesc('Select CSS snippets to be enabled for this profile.')
      .addText(text => {
        text.setPlaceholder('Snippet selection UI to be implemented')
          .setDisabled(true); // This will be replaced by custom UI
      });

    new Setting(contentEl)
      .addButton(button => {
        button.setButtonText('Save Profile')
          .setCta()
          .onClick(async () => {
            if (!this.profile.name) {
              new Notice('Profile name cannot be empty.');
              return;
            }
            this.onSubmit(this.profile);
            this.close();
          });
      })
      .addButton(button => {
        button.setButtonText('Cancel')
          .onClick(() => {
            this.close();
          });
      });
  }

  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
}

