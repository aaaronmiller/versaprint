import { App, PluginSettingTab, Setting, Notice } from 'obsidian';
import VersaPrintPlugin from '../main';
import { ProfileEditorModal } from '../modal/profile-editor';
import { ExportProfile } from '../types/interfaces';

export class VersaPrintSettingTab extends PluginSettingTab {
  plugin: VersaPrintPlugin;

  constructor(app: App, plugin: VersaPrintPlugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display(): void {
    const { containerEl } = this;

    containerEl.empty();

    containerEl.createEl('h2', { text: 'VersaPrint Settings' });

    // Profile Management Section
    new Setting(containerEl)
      .setName('Export Profiles')
      .setHeading();

    this.plugin.settings.profiles.forEach(profile => {
      new Setting(containerEl)
        .setName(profile.name)
        .setDesc(`Format: ${profile.outputFormat.toUpperCase()}, Theme: ${profile.targetTheme}`)
        .addButton(button => {
          button.setButtonText('Edit')
            .onClick(() => {
              new ProfileEditorModal(this.app, this.plugin, profile, async (updatedProfile) => {
                const index = this.plugin.settings.profiles.findIndex(p => p.id === updatedProfile.id);
                if (index !== -1) {
                  this.plugin.settings.profiles[index] = updatedProfile;
                  await this.plugin.saveSettings();
                  this.display(); // Re-render settings tab
                  new Notice('Profile updated successfully.');
                }
              }).open();
            });
        })
        .addButton(button => {
          button.setButtonText('Delete')
            .setClass('mod-warning')
            .onClick(async () => {
              if (confirm(`Are you sure you want to delete profile \'${profile.name}\'?`)) {
                this.plugin.settings.profiles = this.plugin.settings.profiles.filter(p => p.id !== profile.id);
                // If the deleted profile was the default, clear defaultProfileId
                if (this.plugin.settings.defaultProfileId === profile.id) {
                  this.plugin.settings.defaultProfileId = '';
                }
                await this.plugin.saveSettings();
                this.display(); // Re-render settings tab
                new Notice('Profile deleted successfully.');
              }
            });
        });
    });

    new Setting(containerEl)
      .addButton(button => {
        button.setButtonText('Add New Profile')
          .setCta()
          .onClick(() => {
            new ProfileEditorModal(this.app, this.plugin, undefined, async (newProfile) => {
              this.plugin.settings.profiles.push(newProfile);
              await this.plugin.saveSettings();
              this.display(); // Re-render settings tab
              new Notice('New profile created successfully.');
            }).open();
          });
      });

    // Global Defaults Section
    new Setting(containerEl)
      .setName('Global Defaults')
      .setHeading();

    new Setting(containerEl)
      .setName('Default Export Profile')
      .setDesc('Select the profile to be pre-selected in the export modal.')
      .addDropdown(dropdown => {
        dropdown.addOption('', 'None');
        this.plugin.settings.profiles.forEach(profile => {
          dropdown.addOption(profile.id, profile.name);
        });
        dropdown.setValue(this.plugin.settings.defaultProfileId);
        dropdown.onChange(async (value) => {
          this.plugin.settings.defaultProfileId = value;
          await this.plugin.saveSettings();
        });
      });

    new Setting(containerEl)
      .setName('Default Output Path')
      .setDesc('Specify a default folder for saving exported files.')
      .addText(text => text
        .setPlaceholder('path/to/your/exports')
        .setValue(this.plugin.settings.defaultOutputPath)
        .onChange(async (value) => {
          this.plugin.settings.defaultOutputPath = value;
          await this.plugin.saveSettings();
        })
      ); // TODO: Implement AbstractInputSuggest for folder auto-completion

    // Advanced Settings Section
    new Setting(containerEl)
      .setName('Advanced')
      .setHeading();

    new Setting(containerEl)
      .setName('Enable Pandoc Engine')
      .setDesc('Use Pandoc for export (requires Pandoc to be installed).')
      .addToggle(toggle => toggle
        .setValue(this.plugin.settings.enablePandocEngine)
        .onChange(async (value) => {
          this.plugin.settings.enablePandocEngine = value;
          await this.plugin.saveSettings();
          this.display(); // Re-render to show/hide Pandoc Path setting
        })
      );

    if (this.plugin.settings.enablePandocEngine) {
      new Setting(containerEl)
        .setName('Pandoc Path')
        .setDesc('Absolute path to your Pandoc executable (e.g., /usr/local/bin/pandoc).')
        .addText(text => text
          .setPlaceholder('/usr/local/bin/pandoc')
          .setValue(this.plugin.settings.pandocPath)
          .onChange(async (value) => {
            this.plugin.settings.pandocPath = value;
            await this.plugin.saveSettings();
          })
        );
    }
  }
}

