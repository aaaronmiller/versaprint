import { App, TFile } from 'obsidian';
import { CSSSnippet } from '../types/interfaces';

export class CSSProcessor {
  private app: App;

  constructor(app: App) {
    this.app = app;
  }

  async getAvailableSnippets(): Promise<CSSSnippet[]> {
    const snippets: CSSSnippet[] = [];
    try {
      const snippetFiles = await this.app.vault.adapter.list('.obsidian/snippets/');
      if (snippetFiles && snippetFiles.files) {
        for (const filePath of snippetFiles.files) {
          if (filePath.endsWith('.css')) {
            const filename = filePath.split('/').pop() || '';
            const name = filename.replace('.css', '');
            const content = await this.app.vault.adapter.read(filePath);
            
            // Basic parsing for target (print/screen/all) - can be enhanced
            let target: 'print' | 'screen' | 'all' = 'all';
            if (content.includes('@media print')) {
              target = 'print';
            } else if (content.includes('@media screen')) {
              target = 'screen';
            }

            snippets.push({
              filename,
              name,
              target,
              enabled: true, // Assuming all found snippets are initially enabled in Obsidian
              content,
            });
          }
        }
      }
    } catch (error) {
      console.error('VersaPrint: Error scanning CSS snippets:', error);
    }
    return snippets;
  }

  // This function would be used to inline CSS, but the ExportEngine already handles it.
  // Keeping it here for potential future use or modularity.
  async inlineCss(cssContent: string, htmlContent: string): Promise<string> {
    // In a real scenario, a more sophisticated CSS inliner library might be used.
    // For now, we'll assume the CSS is simply placed within <style> tags.
    return `<style>${cssContent}</style>\n${htmlContent}`;
  }
}

