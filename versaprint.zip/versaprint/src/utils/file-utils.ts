import { App, TFile, TFolder } from 'obsidian';

export class FileUtils {
  private app: App;

  constructor(app: App) {
    this.app = app;
  }

  async createUniqueFilename(baseName: string, extension: string, folder?: string): Promise<string> {
    const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
    const baseFilename = `${baseName}_${timestamp}.${extension}`;
    
    let filename = baseFilename;
    let counter = 1;
    
    const fullPath = folder ? `${folder}/${filename}` : filename;
    
    // Check if file exists and increment counter if needed
    while (await this.app.vault.adapter.exists(fullPath)) {
      filename = `${baseName}_${timestamp}_${counter}.${extension}`;
      counter++;
    }
    
    return folder ? `${folder}/${filename}` : filename;
  }

  async ensureFolderExists(folderPath: string): Promise<void> {
    try {
      const folder = this.app.vault.getAbstractFileByPath(folderPath);
      if (!folder || !(folder instanceof TFolder)) {
        await this.app.vault.createFolder(folderPath);
      }
    } catch (error) {
      console.warn(`VersaPrint: Could not create folder ${folderPath}:`, error);
    }
  }

  async saveTextFile(content: string, filePath: string): Promise<void> {
    try {
      // Ensure the parent folder exists
      const parentPath = filePath.substring(0, filePath.lastIndexOf('/'));
      if (parentPath) {
        await this.ensureFolderExists(parentPath);
      }
      
      await this.app.vault.create(filePath, content);
    } catch (error) {
      console.error(`VersaPrint: Could not save file ${filePath}:`, error);
      throw error;
    }
  }

  async readTextFile(filePath: string): Promise<string> {
    try {
      return await this.app.vault.adapter.read(filePath);
    } catch (error) {
      console.error(`VersaPrint: Could not read file ${filePath}:`, error);
      throw error;
    }
  }

  async fileExists(filePath: string): Promise<boolean> {
    try {
      return await this.app.vault.adapter.exists(filePath);
    } catch (error) {
      return false;
    }
  }

  sanitizeFilename(filename: string): string {
    // Remove or replace characters that are not allowed in filenames
    return filename
      .replace(/[<>:"/\\|?*]/g, '_') // Replace invalid characters with underscore
      .replace(/\s+/g, '_') // Replace spaces with underscores
      .replace(/_{2,}/g, '_') // Replace multiple underscores with single underscore
      .trim();
  }

  getFileExtension(filename: string): string {
    const lastDotIndex = filename.lastIndexOf('.');
    return lastDotIndex !== -1 ? filename.substring(lastDotIndex + 1).toLowerCase() : '';
  }

  getBaseName(filename: string): string {
    const lastDotIndex = filename.lastIndexOf('.');
    return lastDotIndex !== -1 ? filename.substring(0, lastDotIndex) : filename;
  }
}

