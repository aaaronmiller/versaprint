import { App, TFile } from 'obsidian';
import { ExportProfile } from '../types/interfaces';

export class HTMLGenerator {
  private app: App;

  constructor(app: App) {
    this.app = app;
  }

  async generateHTMLFromMarkdown(markdownContent: string, profile: ExportProfile): Promise<string> {
    // This is a simplified implementation. In a real scenario, you'd use
    // Obsidian's MarkdownRenderer or a more sophisticated markdown parser.
    
    const div = document.createElement('div');
    div.className = 'markdown-preview-view';
    
    // Use Obsidian's renderer to convert markdown to HTML
    await this.app.renderer.render(markdownContent, div, '', null);
    
    return div.innerHTML;
  }

  async embedImagesAsBase64(htmlContent: string): Promise<string> {
    const imgRegex = /<img[^>]+src=["']([^"']+)["'][^>]*>/g;
    let modifiedHTML = htmlContent;
    
    const matches = htmlContent.matchAll(imgRegex);
    for (const match of matches) {
      const imgSrc = match[1];
      
      // Only process local images (not URLs or data URIs)
      if (!imgSrc.startsWith('http') && !imgSrc.startsWith('data:')) {
        try {
          const imageFile = this.app.metadataCache.getFirstLinkpathDest(
            decodeURIComponent(imgSrc), 
            this.app.workspace.getActiveFile()?.path || ''
          );
          
          if (imageFile instanceof TFile) {
            const arrayBuffer = await this.app.vault.readBinary(imageFile);
            const base64 = this.arrayBufferToBase64(arrayBuffer);
            const mimeType = this.getMimeType(imageFile.extension);
            const dataURI = `data:${mimeType};base64,${base64}`;
            
            modifiedHTML = modifiedHTML.replace(imgSrc, dataURI);
          }
        } catch (error) {
          console.warn(`VersaPrint: Could not embed image ${imgSrc}:`, error);
        }
      }
    }
    
    return modifiedHTML;
  }

  private arrayBufferToBase64(buffer: ArrayBuffer): string {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  private getMimeType(extension: string): string {
    const mimeTypes: Record<string, string> = {
      'png': 'image/png',
      'jpg': 'image/jpeg',
      'jpeg': 'image/jpeg',
      'gif': 'image/gif',
      'svg': 'image/svg+xml',
      'webp': 'image/webp',
      'bmp': 'image/bmp',
      'ico': 'image/x-icon'
    };
    return mimeTypes[extension.toLowerCase()] || 'image/png';
  }

  generateCompleteHTMLDocument(bodyContent: string, title: string, cssContent: string): string {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title}</title>
    <style>
${cssContent}
    </style>
</head>
<body>
    <div class="markdown-reading-view">
        <div class="markdown-preview-view">
            ${bodyContent}
        </div>
    </div>
</body>
</html>`;
  }
}

