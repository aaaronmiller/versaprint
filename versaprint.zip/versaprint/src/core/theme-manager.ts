import { App, TFile } from 'obsidian';
import { Theme } from '../types/interfaces';

export class ThemeManager {
  private app: App;
  private themes: Theme[] = [];

  constructor(app: App) {
    this.app = app;
  }

  async getAvailableThemes(): Promise<Theme[]> {
    if (this.themes.length > 0) return this.themes;

    try {
      // Get built-in themes first
      this.themes = [
        {
          id: 'obsidian-default',
          name: 'Default',
          cssClass: 'theme-light',
          isLight: true,
          path: ''
        },
        {
          id: 'obsidian-dark',
          name: 'Dark',
          cssClass: 'theme-dark',
          isLight: false,
          path: ''
        }
      ];

      // Scan for community themes
      const themeFiles = await this.app.vault.adapter.list('.obsidian/themes/');
      
      if (themeFiles && themeFiles.folders) {
        for (const folder of themeFiles.folders) {
          const themePath = `${folder}/theme.css`;
          try {
            const exists = await this.app.vault.adapter.exists(themePath);
            if (exists) {
              const cssContent = await this.app.vault.adapter.read(themePath);
              const theme = this.parseThemeMetadata(folder, cssContent, themePath);
              if (theme) this.themes.push(theme);
            }
          } catch (error) {
            console.warn(`VersaPrint: Could not read theme at ${themePath}:`, error);
          }
        }
      }
    } catch (error) {
      console.error('VersaPrint: Error scanning themes:', error);
    }

    return this.themes;
  }

  private parseThemeMetadata(folderName: string, cssContent: string, path: string): Theme | null {
    try {
      // Extract theme name from CSS comments
      const nameMatch = cssContent.match(/\/\*[\s\S]*?name:\s*(.+?)[\s\S]*?\*\//i);
      const name = nameMatch ? nameMatch[1].trim() : folderName;

      // Determine if light or dark theme
      const isLight = !cssContent.includes('.theme-dark') || cssContent.includes('.theme-light');
      const cssClass = isLight ? 'theme-light' : 'theme-dark';

      return {
        id: folderName,
        name,
        cssClass,
        isLight,
        path
      };
    } catch (error) {
      console.warn(`VersaPrint: Error parsing theme metadata for ${folderName}:`, error);
      return null;
    }
  }

  getCurrentTheme(): { classes: string[], themeId: string } {
    const body = document.body;
    const classes = Array.from(body.classList);
    
    // Find theme-related classes
    const themeClasses = classes.filter(cls => 
      cls.startsWith('theme-') || cls.includes('obsidian') || cls.includes('minimal')
    );

    // Determine current theme ID
    let themeId = 'obsidian-default';
    if (classes.includes('theme-dark')) {
      themeId = 'obsidian-dark';
    } else {
      // Look for specific theme classes
      const customTheme = classes.find(cls => 
        !['theme-light', 'theme-dark'].includes(cls) && 
        this.themes.some(t => t.cssClass.includes(cls))
      );
      if (customTheme) {
        const theme = this.themes.find(t => t.cssClass.includes(customTheme));
        themeId = theme?.id || themeId;
      }
    }

    return { classes, themeId };
  }

  applyTemporaryTheme(targetThemeId: string): () => void {
    const body = document.body;
    const originalState = this.getCurrentTheme();
    
    // Find target theme
    const targetTheme = this.themes.find(t => t.id === targetThemeId);
    if (!targetTheme) {
      throw new Error(`Theme not found: ${targetThemeId}`);
    }

    // Remove current theme classes
    originalState.classes.forEach(cls => {
      if (cls.startsWith('theme-') || this.isThemeClass(cls)) {
        body.classList.remove(cls);
      }
    });

    // Apply target theme classes
    const targetClasses = targetTheme.cssClass.split(' ');
    targetClasses.forEach(cls => body.classList.add(cls));

    // Return cleanup function
    return () => {
      // Remove applied classes
      targetClasses.forEach(cls => body.classList.remove(cls));
      
      // Restore original classes
      originalState.classes.forEach(cls => body.classList.add(cls));
    };
  }

  private isThemeClass(className: string): boolean {
    return this.themes.some(theme => 
      theme.cssClass.split(' ').includes(className)
    );
  }
}

