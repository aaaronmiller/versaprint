import { App, Notice, TFile } from 'obsidian';
import { ExportProfile, ExportResult } from '../types/interfaces';
import { ThemeManager } from './theme-manager';

export class ExportEngine {
  private app: App;
  private themeManager: ThemeManager;

  constructor(app: App) {
    this.app = app;
    this.themeManager = new ThemeManager(app);
  }

  async exportToPDF(profile: ExportProfile): Promise<ExportResult> {
    let cleanup: (() => void)[] = [];
    
    try {
      // Validate profile
      if (!this.validateProfile(profile)) {
        throw new Error('Invalid export profile configuration');
      }

      new Notice('VersaPrint: Preparing PDF export...');

      // 1. Apply temporary theme if needed
      if (profile.useArxivStyle) {
        cleanup.push(this.applyArxivStyles());
      } else if (profile.targetTheme) {
        const currentTheme = this.themeManager.getCurrentTheme();
        if (currentTheme.themeId !== profile.targetTheme) {
          cleanup.push(this.themeManager.applyTemporaryTheme(profile.targetTheme));
        }
      }

      // 2. Inject CSS @page rules for padding
      if (this.hasPaddingSettings(profile)) {
        cleanup.push(this.injectPagePadding(profile));
      }

      // 3. Apply selected CSS snippets
      if (profile.enabledSnippets.length > 0) {
        cleanup.push(await this.applySelectedSnippets(profile));
      }

      // Small delay to ensure DOM updates are processed
      await this.delay(100);

      // 4. Trigger PDF export
      window.print();

      new Notice('VersaPrint: PDF export dialog opened');

      return {
        success: true,
        format: 'pdf'
      };

    } catch (error) {
      console.error('VersaPrint: Export failed:', error);
      new Notice(`VersaPrint: Export failed - ${error.message}`);
      
      return {
        success: false,
        error: error.message,
        format: 'pdf'
      };
    } finally {
      // Cleanup all temporary changes
      setTimeout(() => {
        cleanup.reverse().forEach(cleanupFn => {
          try {
            cleanupFn();
          } catch (error) {
            console.warn('VersaPrint: Cleanup error:', error);
          }
        });
      }, 200);
    }
  }

  async exportToHTML(profile: ExportProfile): Promise<ExportResult> {
    try {
      new Notice('VersaPrint: Generating HTML export...');

      // Get current note content
      const activeFile = this.app.workspace.getActiveFile();
      if (!activeFile) {
        throw new Error('No active note to export');
      }

      const content = await this.app.vault.read(activeFile);
      const htmlContent = await this.generateHTMLDocument(content, profile);
      
      // Save HTML file
      const outputPath = this.generateOutputPath(activeFile.basename, 'html');
      await this.app.vault.create(outputPath, htmlContent);

      new Notice(`VersaPrint: HTML exported to ${outputPath}`);

      return {
        success: true,
        filePath: outputPath,
        format: 'html'
      };

    } catch (error) {
      console.error('VersaPrint: HTML export failed:', error);
      new Notice(`VersaPrint: HTML export failed - ${error.message}`);
      
      return {
        success: false,
        error: error.message,
        format: 'html'
      };
    }
  }

  private validateProfile(profile: ExportProfile): boolean {
    if (!profile.name || !profile.outputFormat) return false;
    if (profile.outputFormat === 'pdf' && !profile.targetTheme && !profile.useArxivStyle) return false;
    return true;
  }

  private applyArxivStyles(): () => void {
    const styleId = 'versaprint-arxiv-styles';
    
    // Remove existing arxiv styles
    const existing = document.getElementById(styleId);
    if (existing) existing.remove();

    // Create style element with arXiv CSS
    const styleEl = document.createElement('style');
    styleEl.id = styleId;
    styleEl.textContent = this.getArxivCSS();
    document.head.appendChild(styleEl);

    // Return cleanup function
    return () => {
      const el = document.getElementById(styleId);
      if (el) el.remove();
    };
  }

  private injectPagePadding(profile: ExportProfile): () => void {
    const styleId = 'versaprint-page-padding';
    
    // Remove existing padding styles
    const existing = document.getElementById(styleId);
    if (existing) existing.remove();

    // Create @page CSS rule
    const { top, right, bottom, left, unit } = profile.padding;
    const pageCSS = `\n      @page {\n        margin-top: ${top}${unit};\n        margin-right: ${right}${unit};\n        margin-bottom: ${bottom}${unit};\n        margin-left: ${left}${unit};\n      }\n    `;

    const styleEl = document.createElement('style');
    styleEl.id = styleId;
    styleEl.textContent = pageCSS;
    document.head.appendChild(styleEl);

    // Return cleanup function
    return () => {
      const el = document.getElementById(styleId);
      if (el) el.remove();
    };
  }

  private async applySelectedSnippets(profile: ExportProfile): Promise<() => void> {
    const styleId = 'versaprint-custom-snippets';
    
    // Remove existing snippet styles
    const existing = document.getElementById(styleId);
    if (existing) existing.remove();

    let combinedCSS = '';
    
    // Read and combine selected snippets
    for (const snippetName of profile.enabledSnippets) {
      try {
        const snippetPath = `.obsidian/snippets/${snippetName}`;
        const exists = await this.app.vault.adapter.exists(snippetPath);
        if (exists) {
          const cssContent = await this.app.vault.adapter.read(snippetPath);
          combinedCSS += `\n/* ${snippetName} */\n${cssContent}\n`;
        }
      } catch (error) {
        console.warn(`VersaPrint: Could not load snippet ${snippetName}:`, error);
      }
    }

    if (combinedCSS) {
      const styleEl = document.createElement('style');
      styleEl.id = styleId;
      styleEl.textContent = combinedCSS;
      document.head.appendChild(styleEl);
    }

    // Return cleanup function
    return () => {
      const el = document.getElementById(styleId);
      if (el) el.remove();
    };
  }

  private async generateHTMLDocument(content: string, profile: ExportProfile): Promise<string> {
    // This is a simplified placeholder. A real implementation would use
    // MarkdownRenderer.renderMarkdown
    const div = document.createElement('div');
    await this.app.renderer.render(content, div, this.app.workspace.getActiveFile()?.path || '', this.app.workspace.getActiveFile());
    const htmlContent = div.innerHTML;
    
    // Inline CSS styles
    const inlinedCSS = await this.inlineCSS(profile);
    
    // Embed images as base64
    const finalHTML = await this.embedImages(htmlContent);
    
    // Construct complete HTML document
    return `<!DOCTYPE html>\n<html lang="en">\n<head>\n    <meta charset="UTF-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>${this.app.workspace.getActiveFile()?.basename || 'Document'}</title>\n    <style>\n${inlinedCSS}\n    </style>\n</head>\n<body class="${this.getBodyClasses(profile)}">\n    <div class="markdown-reading-view">\n        <div class="markdown-preview-view">\n            ${finalHTML}\n        </div>\n    </div>\n</body>\n</html>`;
  }

  private async inlineCSS(profile: ExportProfile): Promise<string> {
    let css = '';
    
    // Add theme CSS
    if (profile.useArxivStyle) {
      css += this.getArxivCSS();
    } else {
      // This is a simplified approach. A real implementation would need a more
      // robust way to get the full theme CSS.
      css += this.getBaseObsidianCSS();
    }

    // Add snippet CSS
    for (const snippetName of profile.enabledSnippets) {
      try {
        const snippetPath = `.obsidian/snippets/${snippetName}`;
        const exists = await this.app.vault.adapter.exists(snippetPath);
        if (exists) {
          const cssContent = await this.app.vault.adapter.read(snippetPath);
          css += `\n/* ${snippetName} */\n${cssContent}\n`;
        }
      } catch (error) {
        console.warn(`VersaPrint: Could not inline snippet ${snippetName}:`, error);
      }
    }

    return css;
  }

  private async embedImages(htmlContent: string): Promise<string> {
    const imgRegex = /<img[^>]+src=["']([^"']+)["'][^>]*>/g;
    let modifiedHTML = htmlContent;
    
    const matches = htmlContent.matchAll(imgRegex);
    for (const match of matches) {
      const imgSrc = match[1];
      
      if (!imgSrc.startsWith('http') && !imgSrc.startsWith('data:')) {
        try {
          const imageFile = this.app.metadataCache.getFirstLinkpathDest(decodeURIComponent(imgSrc), this.app.workspace.getActiveFile()?.path || '');
          if (imageFile instanceof TFile) {
            const arrayBuffer = await this.app.vault.readBinary(imageFile);
            const base64 = this.arrayBufferToBase64(arrayBuffer);
            const mimeType = this.getMimeType(imageFile.extension);
            const dataURI = `data:${mimeType};base64,${base64}`;
            
            modifiedHTML = modifiedHTML.replace(imgSrc, dataURI);
          }
        } catch (error) {
          console.warn(`VersaPrint: Could not embed image ${imgSrc}:`, error);
        }
      }
    }
    
    return modifiedHTML;
  }

  private hasPaddingSettings(profile: ExportProfile): boolean {
    const { top, right, bottom, left } = profile.padding;
    return top > 0 || right > 0 || bottom > 0 || left > 0;
  }

  private generateOutputPath(baseName: string, extension: string): string {
    const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
    return `${baseName}_${timestamp}.${extension}`;
  }

  private getBodyClasses(profile: ExportProfile): string {
    if (profile.useArxivStyle) {
      return 'theme-light arxiv-style';
    }
    
    const theme = this.themeManager.getCurrentTheme();
    return theme.classes.join(' ');
  }

  private getArxivCSS(): string {
    // This would be loaded from the bundled arxiv-theme.css file
    return `\n/* arXiv Academic Style */\nbody {\n  font-family: 'Times New Roman', Times, serif;\n  font-size: 10pt;\n  line-height: 1.4;\n  max-width: 6.5in;\n  margin: 0 auto;\n  padding: 1in;\n  background: white;\n  color: black;\n}\n\nh1, h2, h3, h4, h5, h6 {\n  font-weight: bold;\n  margin-top: 1em;\n  margin-bottom: 0.5em;\n}\n\nh1 { font-size: 14pt; }\nh2 { font-size: 12pt; }\nh3 { font-size: 11pt; }\n\n.markdown-preview-view {\n  padding: 0;\n}\n\np {\n  text-align: justify;\n  margin-bottom: 0.5em;\n}\n`;
  }

  private getBaseObsidianCSS(): string {
    // Simplified base CSS - in reality this would be more comprehensive
    return `\nbody {\n  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;\n  line-height: 1.6;\n  color: var(--text-normal);\n  background-color: var(--background-primary);\n}\n\n.markdown-preview-view {\n  padding: 2em;\n}\n`;
  }

  private arrayBufferToBase64(buffer: ArrayBuffer): string {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  private getMimeType(extension: string): string {
    const mimeTypes: Record<string, string> = {
      'png': 'image/png',
      'jpg': 'image/jpeg',
      'jpeg': 'image/jpeg',
      'gif': 'image/gif',
      'svg': 'image/svg+xml',
      'webp': 'image/webp'
    };
    return mimeTypes[extension.toLowerCase()] || 'image/png';
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

