<<<<<<< HEAD
# versaprint
Obsidian extension that provides additional options for pdf exporting.
||||||| (empty tree)
=======
# Versaprint - Obsidian pdf exporter extension

A new project scaffolded by the Gnnnome's script.

## Description

[Add a brief project description here.]

## Tech Stack

-   HTML5
-   CSS3 (Synthwave+ Dark Mode)
-   JavaScript (ES6+)
-   Scope: DATA_DRIVEN

## Author

-   **Aaron Miller**

## Getting Started

[Add instructions on how to run or use the project.]

---
*This project was initialized on Mon Jul 21 23:56:33 PDT 2025.*
>>>>>>> a68b1b9 (Initial commit: Scaffolded project with Gnnnome script)
